<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
</head>
<style>
    .main {
        height: 100vh;
    }

    .register-box {
        width: 500px;
        height: 400px;
        box-sizing: border-box;
        border-radius: 10px;
    }
</style>

<body>
    <div class="main d-flex justify-content-center align-items-center">
        <div class="register-box p-5 shadow">
            <form action="<?php echo e(route('register.submit')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <h3 class="mb-4">Registrasi</h3>
                <div>
                    <label for="name">Nama Lengkap: </label>
                    <input type="text" class="form-control" name="name" id="name" required value="<?php echo e(old('name')); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="email">Email: </label>
                    <input type="email" class="form-control" name="email" id="email" required value="<?php echo e(old('email')); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="password">Kata Sandi: </label>
                    <input type="password" class="form-control" name="password" id="password" required>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="confirm-password">Konfirmasi Kata Sandi: </label>
                    <input type="password" class="form-control" name="password_confirmation" id="confirm-password" required>
                </div>
                <div>
                    <button class="btn btn-success form-control mt-3" type="submit">Daftar</button>
                </div>
                <div class="d-flex justify-content-center">
                <p>
                    Sudah memiliki akun?
                    <strong role="button" tabindex="0"> <a href="<?php echo e(route('login')); ?>">Login</a></strong>
                </p>
                </div>
            </form>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\final_PA\resources\views/Auth/registrasi.blade.php ENDPATH**/ ?>