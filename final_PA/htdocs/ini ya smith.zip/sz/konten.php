<?php
require "connect.php";

$querykategori = mysqli_query($mysqli, "SELECT * FROM kategori");

$querykonten = null; // inisialisasi variabel

// get konten by keyword
if (isset($_GET['keyword'])) {
    $keyword = $_GET['keyword'];
    $querykonten = mysqli_query($mysqli, "SELECT * FROM konten WHERE name LIKE '%$keyword%'");
}

//get konten by kategori
else if (isset($_GET['kategori'])) {
    $queryGetkategoriId = mysqli_query($mysqli, "SELECT id FROM kategori WHERE name='$_GET[kategori]'");
    $kategoriId = mysqli_fetch_array($queryGetkategoriId);
    $querykonten = mysqli_query($mysqli, "SELECT * FROM konten WHERE facility_id='$kategoriId[id]'");
}


// get default konten
else {
    $querykonten = mysqli_query($mysqli, "SELECT * FROM konten");
}

$countData = mysqli_num_rows($querykonten);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Siantar Zoo | Kategori</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .active-link {
            color: #AA8B56; /* Ganti dengan warna teks yang diinginkan */
        }
    </style>
</head>

<body>
    <?php require "navbar.php"; ?>

    <!-- banner-->
    <div class="container-fluid banner2 d-flex align-items-center">
        <div class="container">
            <h1 class="text-white text-center">Kategori Hewan dan Layanan</h1>
        </div>
    </div>

    <!-- body -->
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-3 mb-5">
                <h3>Pilih Kategori</h3>
                <ul class="list-group">
                    <?php while ($kategori = mysqli_fetch_array($querykategori)) {
                        $kategoriName = $kategori['name'];
                        $isActive = isset($_GET['kategori']) && $_GET['kategori'] === $kategoriName;
                    ?>
                        <a class="no-decoration" href="konten.php?kategori=<?php echo $kategoriName ?>">
                            <li class="list-group-item <?php if ($isActive) echo 'active-link'; ?>"><?php echo $kategoriName ?></li>
                        </a>
                    <?php } ?>
                </ul>
            </div>
            <div class="col-lg-9">
    <div class="row">
        <?php
        if ($countData < 1) {
        ?>
            <h4 class="text-center my-5">Layanan yang anda cari tidak tersedia</h4>
        <?php } ?>
        <?php while ($konten = mysqli_fetch_array($querykonten)) { ?>
            <div class="col-md-4 mb-4">
                <div class="card h-8">
                    <div class="image-box">
                        <img src="image/<?php echo $konten['foto']; ?>" class="card-img-top" alt="...">
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $konten['name']; ?></h5>
                        <p class="card-text text-truncate">
                            <?php
                            $description = htmlspecialchars_decode($konten['detail']);
                            $truncatedDescription = substr($description, 0, 50); 
                            echo $truncatedDescription . "...";
                            ?>
                        </p>
                        <a href="konten-detail.php?name=<?php echo $konten['name']; ?>" class="btn warna2 text-white">Lihat lainnya</a>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

        </div>
    </div>

    <!--footer-->
    <?php require "footer.php"; ?>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>

</html>